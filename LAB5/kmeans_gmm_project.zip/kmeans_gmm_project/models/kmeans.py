"""
kmeans.py
---------
Pure NumPy implementation of the K-Means algorithm trained with the
Expectation-Maximisation (EM) framework.

EM view of K-Means
------------------
  E-step : assign each point to the nearest centroid  (hard assignment)
  M-step : recompute each centroid as the mean of its assigned points

This corresponds to minimising the within-cluster sum-of-squares (WCSS /
inertia) objective.
"""

import numpy as np


class KMeans:
    """
    K-Means clustering via EM.

    Parameters
    ----------
    k : int
        Number of clusters.
    max_iter : int
        Maximum number of EM iterations.
    tol : float
        Convergence tolerance (centroid shift L2 norm).
    init : str
        Initialisation strategy: 'random' | 'kmeans++'.
    n_init : int
        Number of independent runs; the one with lowest inertia is kept.
    random_state : int or None
        Seed for reproducibility.
    """

    def __init__(
        self,
        k: int = 3,
        max_iter: int = 300,
        tol: float = 1e-4,
        init: str = "random",
        n_init: int = 10,
        random_state: int | None = 42,
    ):
        self.k = k
        self.max_iter = max_iter
        self.tol = tol
        self.init = init
        self.n_init = n_init
        self.random_state = random_state

        # Fitted attributes
        self.centroids_: np.ndarray | None = None
        self.labels_: np.ndarray | None = None
        self.inertia_: float = np.inf
        self.n_iter_: int = 0
        self.inertia_history_: list = []   # per best run

    # ------------------------------------------------------------------
    # Initialisation helpers
    # ------------------------------------------------------------------

    def _init_random(self, X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        """Pick k points uniformly at random from X."""
        idx = rng.choice(len(X), size=self.k, replace=False)
        return X[idx].copy()

    def _init_kmeans_plus_plus(self, X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        """
        KMeans++ initialisation:
        1. Choose first centroid uniformly at random.
        2. For each subsequent centroid, sample a point with probability
           proportional to its squared distance to the nearest already-chosen
           centroid.
        """
        n = len(X)
        centroids = [X[rng.integers(n)]]
        for _ in range(1, self.k):
            # Squared distances to nearest centroid
            dists = np.array([
                min(np.sum((x - c) ** 2) for c in centroids)
                for x in X
            ])
            probs = dists / dists.sum()
            cumulative = np.cumsum(probs)
            r = rng.random()
            idx = np.searchsorted(cumulative, r)
            centroids.append(X[idx])
        return np.array(centroids)

    def _initialise_centroids(self, X: np.ndarray, rng: np.random.Generator) -> np.ndarray:
        if self.init == "kmeans++":
            return self._init_kmeans_plus_plus(X, rng)
        return self._init_random(X, rng)

    # ------------------------------------------------------------------
    # EM steps
    # ------------------------------------------------------------------

    @staticmethod
    def _e_step(X: np.ndarray, centroids: np.ndarray) -> np.ndarray:
        """
        E-step: assign each point to its nearest centroid.

        Returns labels array of shape (n,).
        """
        # Euclidean distances: (n, k)
        diffs = X[:, np.newaxis, :] - centroids[np.newaxis, :, :]   # (n, k, d)
        dists_sq = np.sum(diffs ** 2, axis=2)                        # (n, k)
        return np.argmin(dists_sq, axis=1)

    @staticmethod
    def _m_step(X: np.ndarray, labels: np.ndarray, k: int) -> np.ndarray:
        """
        M-step: recompute centroids as cluster means.

        If a cluster becomes empty its centroid is left unchanged
        (caller passes old centroids for reference).
        """
        d = X.shape[1]
        new_centroids = np.zeros((k, d))
        for j in range(k):
            mask = labels == j
            if mask.sum() > 0:
                new_centroids[j] = X[mask].mean(axis=0)
            else:
                # Empty cluster: keep old centroid (handled by caller)
                new_centroids[j] = np.nan
        return new_centroids

    @staticmethod
    def _inertia(X: np.ndarray, labels: np.ndarray, centroids: np.ndarray) -> float:
        """Within-cluster sum of squared distances (WCSS)."""
        total = 0.0
        for j in range(len(centroids)):
            mask = labels == j
            if mask.sum() > 0:
                total += np.sum((X[mask] - centroids[j]) ** 2)
        return total

    # ------------------------------------------------------------------
    # Single run
    # ------------------------------------------------------------------

    def _fit_single(self, X: np.ndarray, rng: np.random.Generator):
        """Run one complete EM training from a fresh initialisation."""
        centroids = self._initialise_centroids(X, rng)
        inertia_hist = []

        for iteration in range(self.max_iter):
            # E-step
            labels = self._e_step(X, centroids)

            # M-step
            new_centroids = self._m_step(X, labels, self.k)

            # Handle empty clusters: restore old centroid
            empty = np.isnan(new_centroids[:, 0])
            new_centroids[empty] = centroids[empty]

            # Track inertia
            inertia = self._inertia(X, labels, new_centroids)
            inertia_hist.append(inertia)

            # Convergence check
            shift = np.linalg.norm(new_centroids - centroids)
            centroids = new_centroids
            if shift < self.tol:
                break

        labels = self._e_step(X, centroids)
        inertia = self._inertia(X, labels, centroids)
        return centroids, labels, inertia, iteration + 1, inertia_hist

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def fit(self, X: np.ndarray):
        """
        Fit K-Means to X.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)

        Returns
        -------
        self
        """
        seed_seq = np.random.SeedSequence(self.random_state)
        child_seeds = seed_seq.spawn(self.n_init)

        best_inertia = np.inf
        best_centroids = None
        best_labels = None
        best_n_iter = 0
        best_history = []

        for i, child_seed in enumerate(child_seeds):
            rng = np.random.default_rng(child_seed)
            centroids, labels, inertia, n_iter, history = self._fit_single(X, rng)
            if inertia < best_inertia:
                best_inertia = inertia
                best_centroids = centroids
                best_labels = labels
                best_n_iter = n_iter
                best_history = history

        self.centroids_ = best_centroids
        self.labels_ = best_labels
        self.inertia_ = best_inertia
        self.n_iter_ = best_n_iter
        self.inertia_history_ = best_history
        return self

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Assign each point in X to the nearest centroid."""
        if self.centroids_ is None:
            raise RuntimeError("Model has not been fitted yet.")
        return self._e_step(X, self.centroids_)

    def fit_predict(self, X: np.ndarray) -> np.ndarray:
        self.fit(X)
        return self.labels_

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def run_multiple_random_inits(self, X: np.ndarray, n_runs: int = 10):
        """
        Run K-Means `n_runs` times with purely random initialisation and
        collect the inertia of each run.  Used to analyse the sensitivity
        of random initialisation.

        Returns
        -------
        inertias : list of float
        """
        rng = np.random.default_rng(self.random_state)
        inertias = []
        for _ in range(n_runs):
            centroids = self._init_random(X, rng)
            for _ in range(self.max_iter):
                labels = self._e_step(X, centroids)
                new_centroids = self._m_step(X, labels, self.k)
                empty = np.isnan(new_centroids[:, 0])
                new_centroids[empty] = centroids[empty]
                shift = np.linalg.norm(new_centroids - centroids)
                centroids = new_centroids
                if shift < self.tol:
                    break
            labels = self._e_step(X, centroids)
            inertias.append(self._inertia(X, labels, centroids))
        return inertias
