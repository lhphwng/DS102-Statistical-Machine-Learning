"""
gmm.py
------
Pure NumPy implementation of the Gaussian Mixture Model (GMM) trained
with the Expectation-Maximisation (EM) algorithm.

EM for GMM
----------
  Parameters  : mixing weights π_k, means μ_k, covariance matrices Σ_k
  E-step      : compute soft responsibilities r_{nk} = p(z=k | x_n, θ)
  M-step      : update π_k, μ_k, Σ_k using the weighted sufficient statistics
  Log-likelihood is tracked for convergence.
"""

import numpy as np


# ---------------------------------------------------------------------------
# Helper: multivariate Gaussian log-pdf
# ---------------------------------------------------------------------------

def _log_gaussian_pdf(X: np.ndarray, mean: np.ndarray, cov: np.ndarray) -> np.ndarray:
    """
    Compute log N(x; mean, cov) for each row of X.

    Parameters
    ----------
    X    : (n, d)
    mean : (d,)
    cov  : (d, d)

    Returns
    -------
    log_probs : (n,)
    """
    d = X.shape[1]
    diff = X - mean                                  # (n, d)

    # Add a small jitter to cov for numerical stability
    cov_stable = cov + 1e-6 * np.eye(d)

    sign, log_det = np.linalg.slogdet(cov_stable)
    if sign <= 0:
        # Fall back to a large negative number if covariance is degenerate
        return np.full(len(X), -1e10)

    cov_inv = np.linalg.inv(cov_stable)
    # Mahalanobis distance squared for each point
    maha_sq = np.einsum("nd,dd,nd->n", diff, cov_inv, diff)

    log_prob = -0.5 * (d * np.log(2 * np.pi) + log_det + maha_sq)
    return log_prob


# ---------------------------------------------------------------------------
# GMM class
# ---------------------------------------------------------------------------

class GMM:
    """
    Gaussian Mixture Model trained with EM.

    Parameters
    ----------
    k : int
        Number of Gaussian components.
    max_iter : int
        Maximum EM iterations.
    tol : float
        Convergence tolerance on the change in log-likelihood.
    init : str
        Initialisation: 'random' samples k points as means;
                        'kmeans' uses K-Means centres (requires kmeans module).
    random_state : int or None
    """

    def __init__(
        self,
        k: int = 3,
        max_iter: int = 200,
        tol: float = 1e-4,
        init: str = "kmeans",
        random_state: int | None = 42,
    ):
        self.k = k
        self.max_iter = max_iter
        self.tol = tol
        self.init = init
        self.random_state = random_state

        # Fitted parameters
        self.weights_: np.ndarray | None = None   # (k,)
        self.means_: np.ndarray | None = None     # (k, d)
        self.covs_: np.ndarray | None = None      # (k, d, d)
        self.log_likelihood_history_: list = []
        self.n_iter_: int = 0

    # ------------------------------------------------------------------
    # Initialisation
    # ------------------------------------------------------------------

    def _initialise(self, X: np.ndarray, rng: np.random.Generator):
        n, d = X.shape
        if self.init == "kmeans":
            # Use K-Means centres as initial means
            from models.kmeans import KMeans
            km = KMeans(k=self.k, random_state=int(rng.integers(1 << 31)))
            km.fit(X)
            self.means_ = km.centroids_.copy()
        else:
            idx = rng.choice(n, size=self.k, replace=False)
            self.means_ = X[idx].copy()

        self.weights_ = np.full(self.k, 1.0 / self.k)
        # Initialise each covariance as the empirical covariance of X
        emp_cov = np.cov(X.T) + 1e-6 * np.eye(d)
        self.covs_ = np.array([emp_cov.copy() for _ in range(self.k)])

    # ------------------------------------------------------------------
    # EM steps
    # ------------------------------------------------------------------

    def _e_step(self, X: np.ndarray):
        """
        Compute log responsibilities log r_{nk} using the log-sum-exp trick
        for numerical stability.

        Returns
        -------
        responsibilities : (n, k)   — normalised (sum to 1 per row)
        log_likelihood   : float
        """
        n = len(X)
        log_resp = np.zeros((n, self.k))

        for k_idx in range(self.k):
            log_resp[:, k_idx] = (
                np.log(self.weights_[k_idx] + 1e-300)
                + _log_gaussian_pdf(X, self.means_[k_idx], self.covs_[k_idx])
            )

        # Log-sum-exp for numerical stability
        log_resp_max = log_resp.max(axis=1, keepdims=True)
        log_sum = log_resp_max.squeeze() + np.log(
            np.exp(log_resp - log_resp_max).sum(axis=1)
        )
        log_likelihood = log_sum.sum()

        # Normalise responsibilities
        resp = np.exp(log_resp - log_sum[:, np.newaxis])
        return resp, log_likelihood

    def _m_step(self, X: np.ndarray, resp: np.ndarray):
        """
        Update π, μ, Σ from soft assignments.

        Parameters
        ----------
        resp : (n, k)  — responsibilities from E-step
        """
        n, d = X.shape
        N_k = resp.sum(axis=0)          # effective number of points per cluster (k,)

        # Mixing weights
        self.weights_ = N_k / n

        # Means
        self.means_ = (resp.T @ X) / N_k[:, np.newaxis]   # (k, d)

        # Covariances
        for k_idx in range(self.k):
            diff = X - self.means_[k_idx]                  # (n, d)
            # Weighted outer product sum
            cov = (resp[:, k_idx:k_idx+1] * diff).T @ diff  # (d, d)
            self.covs_[k_idx] = cov / N_k[k_idx] + 1e-6 * np.eye(d)

    # ------------------------------------------------------------------
    # Fit
    # ------------------------------------------------------------------

    def fit(self, X: np.ndarray):
        """
        Fit GMM to X via EM.

        Parameters
        ----------
        X : np.ndarray of shape (n_samples, n_features)

        Returns
        -------
        self
        """
        rng = np.random.default_rng(self.random_state)
        self._initialise(X, rng)

        prev_log_likelihood = -np.inf
        self.log_likelihood_history_ = []

        for iteration in range(self.max_iter):
            # E-step
            resp, log_likelihood = self._e_step(X)
            self.log_likelihood_history_.append(log_likelihood)

            # Convergence check
            delta = log_likelihood - prev_log_likelihood
            if abs(delta) < self.tol and iteration > 0:
                break
            prev_log_likelihood = log_likelihood

            # M-step
            self._m_step(X, resp)

        self.n_iter_ = iteration + 1
        return self

    # ------------------------------------------------------------------
    # Predict / score
    # ------------------------------------------------------------------

    def predict(self, X: np.ndarray) -> np.ndarray:
        """Hard cluster assignment: argmax of responsibilities."""
        resp, _ = self._e_step(X)
        return np.argmax(resp, axis=1)

    def predict_proba(self, X: np.ndarray) -> np.ndarray:
        """Soft responsibilities for each point."""
        resp, _ = self._e_step(X)
        return resp

    def score(self, X: np.ndarray) -> float:
        """Mean log-likelihood per sample."""
        _, ll = self._e_step(X)
        return ll / len(X)

    def score_samples(self, X: np.ndarray) -> np.ndarray:
        """
        Log-likelihood of each sample under the mixture.
        Returns array of shape (n,).
        """
        n = len(X)
        log_resp = np.zeros((n, self.k))
        for k_idx in range(self.k):
            log_resp[:, k_idx] = (
                np.log(self.weights_[k_idx] + 1e-300)
                + _log_gaussian_pdf(X, self.means_[k_idx], self.covs_[k_idx])
            )
        log_resp_max = log_resp.max(axis=1, keepdims=True)
        log_sum = log_resp_max.squeeze() + np.log(
            np.exp(log_resp - log_resp_max).sum(axis=1)
        )
        return log_sum
