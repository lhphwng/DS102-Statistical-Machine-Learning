"""
main_gmm_a2.py
==============
GMM Assignment 2
----------------
Use a Gaussian Mixture Model to FILTER OUT the background of an image.

Approach
--------
1. Load an image (or create a synthetic test image if none is provided).
2. Reshape image pixels to (H*W, 3) — each row is an RGB pixel.
3. Fit a GMM with k=2 (background / foreground) or k=3 for richer scenes.
4. Identify the "background" component (typically the dominant one with
   highest mixing weight, or the one whose mean is closest to known BG colour).
5. Assign each pixel a soft probability of being background.
6. Threshold to produce a binary mask: foreground vs background.
7. Display / save the results.

Run
---
    python main_gmm_a2.py [--image path/to/image.png] [--k 3] [--threshold 0.5]

If no image is provided, a synthetic test image is generated automatically.
"""

import os
import sys
import argparse
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))

from models import GMM
from visualization import plot_foreground_background

OUT_DIR = os.path.join(os.path.dirname(__file__), "results", "gmm_a2")
os.makedirs(OUT_DIR, exist_ok=True)


# ---------------------------------------------------------------------------
# Synthetic test image
# ---------------------------------------------------------------------------

def create_synthetic_image(seed: int = 0) -> np.ndarray:
    """
    Create a 120×160 RGB synthetic image:
    - Background: uniform blue-grey  N((180,190,200), 5²·I)
    - Foreground object: orange ellipse N((220,100,50), 15²·I)
    - Foreground object 2: green rectangle  N((60,160,80), 10²·I)
    Returns uint8 array of shape (120, 160, 3).
    """
    rng = np.random.default_rng(seed)
    H, W = 120, 160
    img = np.zeros((H, W, 3), dtype=np.float32)

    # Background noise
    img[:, :, 0] = rng.normal(180, 8, (H, W))
    img[:, :, 1] = rng.normal(190, 8, (H, W))
    img[:, :, 2] = rng.normal(200, 8, (H, W))

    # Foreground ellipse (orange)
    cy, cx = 55, 80
    for y in range(H):
        for x in range(W):
            if ((y - cy) / 30) ** 2 + ((x - cx) / 50) ** 2 < 1:
                img[y, x, 0] = rng.normal(220, 12)
                img[y, x, 1] = rng.normal(100, 12)
                img[y, x, 2] = rng.normal(50,  12)

    # Foreground rectangle (green)
    img[80:110, 10:60, 0] = rng.normal(60,  10, (30, 50))
    img[80:110, 10:60, 1] = rng.normal(160, 10, (30, 50))
    img[80:110, 10:60, 2] = rng.normal(80,  10, (30, 50))

    return np.clip(img, 0, 255).astype(np.uint8)


# ---------------------------------------------------------------------------
# Load or create image
# ---------------------------------------------------------------------------

def load_image(path: str | None) -> np.ndarray:
    """
    Load an image from path.  Falls back to synthetic if path is None or
    the file is not found.  Uses only NumPy + matplotlib (no cv2 / PIL).
    """
    if path is not None and os.path.isfile(path):
        img = plt.imread(path)
        # Normalise to 0-255 uint8
        if img.dtype == np.float32 or img.dtype == np.float64:
            img = (img * 255).astype(np.uint8)
        if img.ndim == 2:                        # grayscale → RGB
            img = np.stack([img] * 3, axis=-1)
        if img.shape[2] == 4:                    # RGBA → RGB
            img = img[:, :, :3]
        return img
    else:
        print("[Image] No valid image path provided → using synthetic test image.")
        return create_synthetic_image(seed=0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="GMM Background Subtraction")
    parser.add_argument("--image",     type=str,   default=None,
                        help="Path to input image (PNG/JPG). If omitted, a synthetic image is used.")
    parser.add_argument("--k",         type=int,   default=3,
                        help="Number of GMM components (default: 3).")
    parser.add_argument("--threshold", type=float, default=0.5,
                        help="Background probability threshold (default: 0.5).")
    parser.add_argument("--max_iter",  type=int,   default=100,
                        help="GMM max EM iterations (default: 100).")
    args = parser.parse_args()

    print("=" * 65)
    print("  GMM Assignment 2 — Image Background Subtraction")
    print("=" * 65)

    # ------------------------------------------------------------------
    # 1. Load image
    # ------------------------------------------------------------------
    img = load_image(args.image)
    H, W, C = img.shape
    print(f"\n[Image] Shape: {img.shape}  dtype: {img.dtype}")

    # ------------------------------------------------------------------
    # 2. Flatten to pixel matrix
    # ------------------------------------------------------------------
    pixels = img.reshape(-1, 3).astype(np.float64)
    print(f"[Pixels] Flattened to ({pixels.shape[0]}, {pixels.shape[1]})")

    # Normalise to [0, 1] for numerical stability
    pixels_norm = pixels / 255.0

    # ------------------------------------------------------------------
    # 3. Fit GMM
    # ------------------------------------------------------------------
    print(f"\n[GMM] Fitting k={args.k} components ...")
    gmm = GMM(k=args.k, max_iter=args.max_iter, tol=1e-4, init="random", random_state=42)
    gmm.fit(pixels_norm)

    print(f"      Converged in {gmm.n_iter_} iterations")
    print(f"      Mixing weights: {gmm.weights_.round(4)}")
    print(f"      Component means (×255):")
    for i, mu in enumerate(gmm.means_):
        print(f"        Component {i}: {(mu * 255).round(1)}")

    # ------------------------------------------------------------------
    # 4. Compute per-pixel log-likelihoods → identify background
    # ------------------------------------------------------------------
    resp = gmm.predict_proba(pixels_norm)  # (n_pixels, k)

    # Identify background as the component with the highest mixing weight
    # (most dominant component = most likely to be background)
    bg_component = int(np.argmax(gmm.weights_))
    mean_rgb_str = np.round(gmm.means_[bg_component] * 255, 1)
    print(f"\n[Background] Identified component {bg_component} as background "
          f"(weight={gmm.weights_[bg_component]:.4f}, "
          f"mean_RGB={mean_rgb_str})")

    # ------------------------------------------------------------------
    # 5. Build binary foreground mask
    # ------------------------------------------------------------------
    bg_prob = resp[:, bg_component].reshape(H, W)  # probability of being background
    fg_mask = (bg_prob < args.threshold)            # True = foreground pixel

    print(f"\n[Mask] Foreground pixels: {fg_mask.sum()} / {H*W} "
          f"({100*fg_mask.mean():.1f}%)")

    # ------------------------------------------------------------------
    # 6. Produce foreground / background images
    # ------------------------------------------------------------------
    fg_img = img.copy()
    fg_img[~fg_mask] = 0          # black out background

    bg_img = img.copy()
    bg_img[fg_mask] = 0           # black out foreground

    # ------------------------------------------------------------------
    # 7. Plot
    # ------------------------------------------------------------------
    fig = plot_foreground_background(
        img, fg_img, bg_img,
        save_path=os.path.join(OUT_DIR, "gmm_a2_bg_subtraction.png"),
    )
    plt.close(fig)

    # Probability map
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    axes[0].imshow(img)
    axes[0].set_title("Original Image")
    axes[0].axis("off")

    im = axes[1].imshow(bg_prob, cmap="coolwarm", vmin=0, vmax=1)
    axes[1].set_title(f"Background Probability (component {bg_component})")
    axes[1].axis("off")
    plt.colorbar(im, ax=axes[1], fraction=0.046, pad=0.04)

    fig.suptitle("GMM Background Subtraction — Probability Map", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a2_prob_map.png"), dpi=150)
    plt.close(fig)

    # GMM pixel cluster assignment
    pixel_labels = gmm.predict(pixels_norm).reshape(H, W)
    fig, ax = plt.subplots(figsize=(7, 5))
    im = ax.imshow(pixel_labels, cmap="tab10", vmin=0, vmax=9)
    ax.set_title(f"GMM Pixel Cluster Assignment (k={args.k})")
    ax.axis("off")
    plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a2_pixel_labels.png"), dpi=150)
    plt.close(fig)

    # Log-likelihood convergence
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(range(1, len(gmm.log_likelihood_history_) + 1),
            gmm.log_likelihood_history_, marker="o", markersize=3, color="#2ECC71")
    ax.set_xlabel("EM Iteration")
    ax.set_ylabel("Log-Likelihood")
    ax.set_title("GMM A2 — EM Convergence on Image Pixels")
    ax.grid(True, linestyle="--", alpha=0.5)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a2_loglik.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Commentary
    # ------------------------------------------------------------------
    print("""
┌─────────────────────────────────────────────────────────────────┐
│   COMMENT: GMM for Image Background Subtraction                 │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  APPROACH:                                                      │
│   • Each image pixel is treated as a 3-D point (R, G, B).      │
│   • A GMM with k components is fitted to all pixels.            │
│   • The component with the highest mixing weight π_k is         │
│     identified as the BACKGROUND (it covers the most pixels).   │
│   • Pixels with high P(background | pixel) are masked out.      │
│                                                                 │
│  WHY GMM WORKS WELL HERE:                                       │
│   • Pixel colours cluster naturally in RGB space.               │
│   • Background pixels share similar colour statistics →         │
│     modelled by one (or a few) Gaussian component(s).           │
│   • Foreground objects have different colour distributions →     │
│     captured by the remaining components.                       │
│   • Full covariance matrices allow the model to capture         │
│     colour correlations (e.g. warm orange: high R, low B).      │
│                                                                 │
│  LIMITATIONS:                                                   │
│   • Purely colour-based: ignores spatial structure.             │
│   • k must be chosen carefully. Too few → bg/fg blend.          │
│   • The background label assignment (by weight) can fail if     │
│     the foreground object is very large.                        │
│   • More advanced methods (MOG2, CNNs) use temporal or spatial  │
│     context for better accuracy.                                │
└─────────────────────────────────────────────────────────────────┘
""")

    print(f"[Done] Figures saved to: {OUT_DIR}/")


if __name__ == "__main__":
    main()
