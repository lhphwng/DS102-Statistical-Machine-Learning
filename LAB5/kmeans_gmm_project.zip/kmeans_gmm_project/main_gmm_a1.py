"""
main_gmm_a1.py
==============
GMM Assignment 1
----------------
Implement Gaussian Mixture Model (GMM) with EM — NumPy only.

Dataset : same balanced toy dataset as K-Means A1
          N((2,2), I), N((8,3), I), N((3,6), I)   200 pts each

Tasks
-----
1. Implement GMM (done in models/gmm.py).
2. Train with EM.
3. Compare results with K-Means.
4. Show GMM component ellipses.

Run
---
    python main_gmm_a1.py
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))

from data import generate_dataset_gmm
from models import GMM, KMeans
from visualization import (
    plot_gmm_components,
    plot_log_likelihood,
    plot_true_vs_predicted,
    cluster_purity,
    contingency_matrix,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "results", "gmm_a1")
os.makedirs(OUT_DIR, exist_ok=True)


def print_gmm_params(gmm: GMM):
    for k in range(gmm.k):
        print(f"\n  Component {k}:")
        print(f"    Weight (π)    : {gmm.weights_[k]:.4f}")
        print(f"    Mean (μ)      : {gmm.means_[k]}")
        print(f"    Covariance (Σ):\n{gmm.covs_[k]}")


def main():
    print("=" * 65)
    print("  GMM Assignment 1 — Gaussian Mixture Model with EM")
    print("=" * 65)

    # ------------------------------------------------------------------
    # 1. Generate dataset
    # ------------------------------------------------------------------
    X, y_true = generate_dataset_gmm(seed=42)
    print(f"\n[Data] Shape: {X.shape}")
    unique, counts = np.unique(y_true, return_counts=True)
    print(f"       Class distribution: {dict(zip(unique, counts))}")

    # ------------------------------------------------------------------
    # 2. Train GMM (KMeans init)
    # ------------------------------------------------------------------
    print("\n[GMM] Training with EM (KMeans initialisation)...")
    gmm = GMM(k=3, max_iter=200, tol=1e-6, init="kmeans", random_state=42)
    gmm.fit(X)

    labels_gmm = gmm.predict(X)
    purity_gmm = cluster_purity(y_true, labels_gmm)

    print(f"      Converged in {gmm.n_iter_} EM iterations")
    print(f"      Final log-likelihood per sample: {gmm.score(X):.4f}")
    print(f"      Cluster purity: {purity_gmm:.4f}")
    print_gmm_params(gmm)

    cont_gmm = contingency_matrix(y_true, labels_gmm)
    print(f"\n      Contingency matrix (true × predicted):\n{cont_gmm}")

    # ------------------------------------------------------------------
    # 3. Compare with K-Means on same data
    # ------------------------------------------------------------------
    km = KMeans(k=3, max_iter=300, tol=1e-4, init="random", n_init=10, random_state=42)
    km.fit(X)
    purity_km = cluster_purity(y_true, km.labels_)

    print(f"\n[Comparison]")
    print(f"  K-Means purity : {purity_km:.4f}   inertia: {km.inertia_:.2f}")
    print(f"  GMM     purity : {purity_gmm:.4f}   log-lik: {gmm.score(X):.4f}")

    # ------------------------------------------------------------------
    # Plot 1 – GMM component ellipses
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(7, 5))
    plot_gmm_components(
        X, labels_gmm, gmm.means_, gmm.covs_, gmm.weights_,
        title="GMM A1 — Learned Components with 2-σ Ellipses",
        ax=ax,
    )
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a1_components.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 2 – Log-likelihood convergence
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(6, 4))
    plot_log_likelihood(
        gmm.log_likelihood_history_,
        title="GMM A1 — EM Log-Likelihood Convergence",
        ax=ax,
    )
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a1_loglik.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 3 – Ground truth vs GMM prediction
    # ------------------------------------------------------------------
    fig = plot_true_vs_predicted(
        X, y_true, labels_gmm,
        suptitle="GMM A1 — Ground Truth vs Predicted Clusters",
        save_path=os.path.join(OUT_DIR, "gmm_a1_clusters.png"),
    )
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 4 – Side-by-side: K-Means vs GMM
    # ------------------------------------------------------------------
    from visualization.plotter import COLORS
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    for idx, c in enumerate(np.unique(km.labels_)):
        mask = km.labels_ == c
        axes[0].scatter(X[mask, 0], X[mask, 1], color=COLORS[idx], alpha=0.4, s=18, label=f"C{c}")
    axes[0].scatter(km.centroids_[:, 0], km.centroids_[:, 1],
                    marker="*", s=250, c="black", zorder=5)
    axes[0].set_title(f"K-Means  (purity={purity_km:.3f})")
    axes[0].legend(fontsize=8)

    plot_gmm_components(
        X, labels_gmm, gmm.means_, gmm.covs_, gmm.weights_,
        title=f"GMM  (purity={purity_gmm:.3f})",
        ax=axes[1],
    )
    fig.suptitle("GMM A1 — K-Means vs GMM Comparison", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "gmm_a1_vs_kmeans.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Commentary
    # ------------------------------------------------------------------
    print("""
┌─────────────────────────────────────────────────────────────────┐
│       COMMENT: GMM vs K-Means                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  GMM is a PROBABILISTIC model: it assigns SOFT memberships      │
│  (responsibilities) instead of hard labels.                     │
│                                                                 │
│  EM for GMM:                                                    │
│    E-step: compute r_{nk} = P(z=k | x_n, θ)  (soft assigns)    │
│    M-step: update π_k, μ_k, Σ_k via weighted MLE               │
│                                                                 │
│  Advantages over K-Means:                                       │
│    ① Models cluster SHAPE via full Σ_k (not just sphere).       │
│    ② Models cluster SIZE via mixing weight π_k.                 │
│    ③ Provides uncertainty estimates (responsibilities).         │
│    ④ Monotonically increasing log-likelihood → well-defined      │
│       convergence criterion.                                    │
│                                                                 │
│  On balanced, isotropic clusters (this dataset) both methods    │
│  achieve similar purity. The advantage of GMM becomes clear     │
│  on anisotropic or imbalanced data (see K-Means A2, A3).        │
└─────────────────────────────────────────────────────────────────┘
""")

    print(f"[Done] Figures saved to: {OUT_DIR}/")


if __name__ == "__main__":
    main()
