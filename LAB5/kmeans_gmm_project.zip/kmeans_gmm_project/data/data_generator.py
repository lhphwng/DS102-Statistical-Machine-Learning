"""
data_generator.py
-----------------
Utility functions to generate Gaussian toy datasets for K-Means and GMM experiments.
All operations use NumPy only.
"""

import numpy as np


def generate_gaussian_cluster(n_points: int, mean: list, cov: list, rng: np.random.Generator) -> np.ndarray:
    """
    Generate `n_points` samples from a 2-D Gaussian distribution N(mean, cov).

    Parameters
    ----------
    n_points : int
        Number of data points to generate.
    mean : list or array-like of shape (2,)
        Mean vector [mu_x, mu_y].
    cov : list or array-like of shape (2, 2)
        Covariance matrix.
    rng : np.random.Generator
        NumPy random generator (for reproducibility).

    Returns
    -------
    np.ndarray of shape (n_points, 2)
    """
    mean = np.array(mean, dtype=float)
    cov = np.array(cov, dtype=float)
    # Cholesky decomposition:  X = mean + L @ Z,  Z ~ N(0, I)
    L = np.linalg.cholesky(cov)
    Z = rng.standard_normal((n_points, 2))
    return (Z @ L.T) + mean


def generate_dataset_kmeans_a1(seed: int = 42):
    """
    K-Means Assignment 1:
        200 pts ~ N((2,2), I)
        200 pts ~ N((8,3), I)
        200 pts ~ N((3,6), I)
    Returns X (600,2) and true labels (600,).
    """
    rng = np.random.default_rng(seed)
    sigma = np.eye(2)
    clusters = [
        (200, [2, 2], sigma),
        (200, [8, 3], sigma),
        (200, [3, 6], sigma),
    ]
    X_parts, y_parts = [], []
    for label, (n, mean, cov) in enumerate(clusters):
        X_parts.append(generate_gaussian_cluster(n, mean, cov, rng))
        y_parts.append(np.full(n, label))
    X = np.vstack(X_parts)
    y = np.concatenate(y_parts)
    return X, y


def generate_dataset_kmeans_a2(seed: int = 42):
    """
    K-Means Assignment 2 (imbalanced):
        1200 pts ~ N((2,2), I)
         200 pts ~ N((8,3), I)
        1000 pts ~ N((3,6), I)
    Returns X (2400,2) and true labels (2400,).
    """
    rng = np.random.default_rng(seed)
    sigma = np.eye(2)
    clusters = [
        (1200, [2, 2], sigma),
        (200,  [8, 3], sigma),
        (1000, [3, 6], sigma),
    ]
    X_parts, y_parts = [], []
    for label, (n, mean, cov) in enumerate(clusters):
        X_parts.append(generate_gaussian_cluster(n, mean, cov, rng))
        y_parts.append(np.full(n, label))
    X = np.vstack(X_parts)
    y = np.concatenate(y_parts)
    return X, y


def generate_dataset_kmeans_a3(seed: int = 42):
    """
    K-Means Assignment 3 (different covariances):
        200 pts ~ N((2,2), Sigma1)   Sigma1 = I
        200 pts ~ N((8,3), Sigma1)
        200 pts ~ N((3,6), Sigma2)   Sigma2 = diag(10, 1)
    Returns X (600,2) and true labels (600,).
    """
    rng = np.random.default_rng(seed)
    sigma1 = np.eye(2)
    sigma2 = np.array([[10, 0], [0, 1]], dtype=float)
    clusters = [
        (200, [2, 2], sigma1),
        (200, [8, 3], sigma1),
        (200, [3, 6], sigma2),
    ]
    X_parts, y_parts = [], []
    for label, (n, mean, cov) in enumerate(clusters):
        X_parts.append(generate_gaussian_cluster(n, mean, cov, rng))
        y_parts.append(np.full(n, label))
    X = np.vstack(X_parts)
    y = np.concatenate(y_parts)
    return X, y


def generate_dataset_gmm(seed: int = 42):
    """
    GMM Assignment 1: same layout as K-Means A1 for a direct comparison.
        200 pts ~ N((2,2), I)
        200 pts ~ N((8,3), I)
        200 pts ~ N((3,6), I)
    Returns X (600,2) and true labels (600,).
    """
    return generate_dataset_kmeans_a1(seed=seed)
