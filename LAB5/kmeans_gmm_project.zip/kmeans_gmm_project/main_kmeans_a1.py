"""
main_kmeans_a1.py
=================
K-Means Assignment 1
--------------------
Dataset : 600 balanced points (200 per cluster)
          N((2,2), I), N((8,3), I), N((3,6), I)

Tasks
-----
1. Generate dataset.
2. Implement K-Means (EM) using NumPy only.
3. Train and evaluate.
4. Comment on the effect of random centroid initialisation.

Run
---
    python main_kmeans_a1.py
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")           # non-interactive backend (safe for all envs)
import matplotlib.pyplot as plt

# Make project root importable when running directly from the folder
sys.path.insert(0, os.path.dirname(__file__))

from data import generate_dataset_kmeans_a1
from models import KMeans
from visualization import (
    plot_true_vs_predicted,
    plot_inertia_curve,
    plot_random_init_sensitivity,
    cluster_purity,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "results", "kmeans_a1")
os.makedirs(OUT_DIR, exist_ok=True)


def main():
    print("=" * 65)
    print("  K-Means Assignment 1 — Balanced Dataset / Random Init Effect")
    print("=" * 65)

    # ------------------------------------------------------------------
    # 1. Generate dataset
    # ------------------------------------------------------------------
    X, y_true = generate_dataset_kmeans_a1(seed=42)
    print(f"\n[Data] Shape: {X.shape}")
    print(f"       Class distribution: {dict(zip(*np.unique(y_true, return_counts=True)))}")

    # ------------------------------------------------------------------
    # 2 & 3. Train K-Means (best of n_init=10 random runs)
    # ------------------------------------------------------------------
    km = KMeans(k=3, max_iter=300, tol=1e-4, init="random", n_init=10, random_state=0)
    km.fit(X)

    purity = cluster_purity(y_true, km.labels_)
    print(f"\n[K-Means] Converged in {km.n_iter_} iterations")
    print(f"          Final inertia : {km.inertia_:.2f}")
    print(f"          Cluster purity: {purity:.4f}")
    print(f"\n          Discovered centroids:\n{km.centroids_}")

    # ------------------------------------------------------------------
    # Plot 1 – Ground truth vs predicted
    # ------------------------------------------------------------------
    fig = plot_true_vs_predicted(
        X, y_true, km.labels_,
        suptitle="K-Means A1 — Balanced Dataset (200 pts × 3)",
        save_path=os.path.join(OUT_DIR, "a1_clusters.png"),
    )
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 2 – Inertia convergence
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(6, 4))
    plot_inertia_curve(
        km.inertia_history_,
        title="K-Means A1 — Inertia Convergence (best run)",
        ax=ax,
    )
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "a1_inertia_curve.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # 4. Analyse random initialisation sensitivity
    # ------------------------------------------------------------------
    print("\n[Analysis] Running 20 independent random-init experiments...")
    inertias = km.run_multiple_random_inits(X, n_runs=20)
    inertia_arr = np.array(inertias)
    print(f"           Inertia — min: {inertia_arr.min():.2f}  "
          f"max: {inertia_arr.max():.2f}  "
          f"std: {inertia_arr.std():.2f}")

    fig = plot_random_init_sensitivity(
        inertias,
        title="K-Means A1 — Inertia Spread over 20 Random Initialisations",
        save_path=os.path.join(OUT_DIR, "a1_random_init_sensitivity.png"),
    )
    plt.close(fig)

    # ------------------------------------------------------------------
    # Commentary
    # ------------------------------------------------------------------
    print("""
┌─────────────────────────────────────────────────────────────────┐
│           COMMENT: Effect of Random Initialisation              │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  K-Means with random initialisation is highly sensitive to the  │
│  starting centroid positions:                                   │
│                                                                 │
│  • Bad init → converges to a LOCAL optimum (high inertia).      │
│    The algorithm may split a true cluster or merge two true     │
│    clusters, yielding poor boundaries.                          │
│                                                                 │
│  • The std of inertia across 20 runs shows the VARIANCE of      │
│    outcomes. Large std = the algorithm is unreliable without    │
│    re-running multiple times.                                   │
│                                                                 │
│  • Mitigation strategies:                                       │
│      ① Run multiple restarts (n_init) and keep the best.        │
│      ② Use KMeans++ initialisation, which spreads the initial   │
│         centroids to reduce the chance of poor convergence.     │
│                                                                 │
│  On this BALANCED, WELL-SEPARATED dataset the effect is mild    │
│  (clusters are far apart), but on harder datasets the impact    │
│  of bad initialisation is dramatic.                             │
└─────────────────────────────────────────────────────────────────┘
""")

    print(f"[Done] Figures saved to: {OUT_DIR}/")


if __name__ == "__main__":
    main()
