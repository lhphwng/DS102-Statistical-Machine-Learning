"""
plotter.py
----------
Matplotlib-based plotting helpers shared across all assignments.
"""

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.patches import Ellipse


# ---------------------------------------------------------------------------
# Color palette
# ---------------------------------------------------------------------------
COLORS = ["#E74C3C", "#3498DB", "#2ECC71", "#F39C12", "#9B59B6"]
MARKERS = ["o", "s", "^", "D", "v"]


# ---------------------------------------------------------------------------
# General scatter helpers
# ---------------------------------------------------------------------------

def plot_clusters(
    X: np.ndarray,
    labels: np.ndarray,
    centroids: np.ndarray | None = None,
    title: str = "K-Means Clustering",
    ax: plt.Axes | None = None,
    true_labels: np.ndarray | None = None,
    alpha: float = 0.45,
):
    """
    Scatter plot of clustered data.

    Parameters
    ----------
    X          : (n, 2)  data points
    labels     : (n,)    cluster assignments
    centroids  : (k, 2) or None
    title      : plot title
    ax         : matplotlib Axes (creates one if None)
    true_labels: (n,) optional ground-truth for outline colouring
    alpha      : point transparency
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 5))

    unique = np.unique(labels)
    for idx, c in enumerate(unique):
        mask = labels == c
        ax.scatter(
            X[mask, 0], X[mask, 1],
            color=COLORS[idx % len(COLORS)],
            alpha=alpha,
            s=25,
            label=f"Cluster {c}",
        )

    if centroids is not None:
        ax.scatter(
            centroids[:, 0], centroids[:, 1],
            marker="*", s=300, c="black", zorder=5, label="Centroids",
        )

    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    ax.set_xlabel("Feature 1")
    ax.set_ylabel("Feature 2")
    return ax


def plot_true_vs_predicted(
    X: np.ndarray,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    suptitle: str = "",
    save_path: str | None = None,
):
    """Side-by-side plot: ground truth | predicted clusters."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 5))
    plot_clusters(X, y_true,  title="Ground Truth",       ax=axes[0])
    plot_clusters(X, y_pred,  title="Predicted Clusters", ax=axes[1])
    if suptitle:
        fig.suptitle(suptitle, fontsize=13, fontweight="bold")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


# ---------------------------------------------------------------------------
# Inertia / convergence plots
# ---------------------------------------------------------------------------

def plot_inertia_curve(
    history: list,
    title: str = "K-Means Inertia Convergence",
    ax: plt.Axes | None = None,
    save_path: str | None = None,
):
    """Plot inertia vs. iteration number."""
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 4))
    ax.plot(range(1, len(history) + 1), history, marker="o", markersize=4, color="#3498DB")
    ax.set_xlabel("Iteration")
    ax.set_ylabel("Inertia (WCSS)")
    ax.set_title(title)
    ax.grid(True, linestyle="--", alpha=0.5)
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return ax


def plot_random_init_sensitivity(
    inertias: list,
    title: str = "Inertia Distribution over Random Initialisations",
    save_path: str | None = None,
):
    """Box + strip plot of inertia across multiple random initialisations."""
    fig, ax = plt.subplots(figsize=(6, 4))
    ax.boxplot(inertias, vert=True, patch_artist=True,
               boxprops=dict(facecolor="#AED6F1"))
    ax.scatter([1] * len(inertias), inertias, color="#E74C3C", zorder=3, alpha=0.7)
    ax.set_xticks([1])
    ax.set_xticklabels(["Random init"])
    ax.set_ylabel("Inertia (WCSS)")
    ax.set_title(title)
    ax.grid(True, linestyle="--", alpha=0.4, axis="y")
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig


# ---------------------------------------------------------------------------
# GMM-specific: covariance ellipses
# ---------------------------------------------------------------------------

def _cov_to_ellipse_params(cov: np.ndarray, n_std: float = 2.0):
    """Return (width, height, angle_deg) for a confidence ellipse."""
    eigenvalues, eigenvectors = np.linalg.eigh(cov)
    order = eigenvalues.argsort()[::-1]
    eigenvalues = eigenvalues[order]
    eigenvectors = eigenvectors[:, order]
    angle = np.degrees(np.arctan2(*eigenvectors[:, 0][::-1]))
    width, height = 2 * n_std * np.sqrt(eigenvalues)
    return width, height, angle


def plot_gmm_components(
    X: np.ndarray,
    labels: np.ndarray,
    means: np.ndarray,
    covs: np.ndarray,
    weights: np.ndarray,
    title: str = "GMM Components",
    ax: plt.Axes | None = None,
    save_path: str | None = None,
):
    """
    Scatter of data coloured by GMM component assignment + 2-sigma ellipses.
    """
    if ax is None:
        _, ax = plt.subplots(figsize=(7, 5))

    unique = np.unique(labels)
    for idx, c in enumerate(unique):
        mask = labels == c
        ax.scatter(
            X[mask, 0], X[mask, 1],
            color=COLORS[idx % len(COLORS)],
            alpha=0.4, s=20,
            label=f"Component {c}  (π={weights[c]:.2f})",
        )
        # Draw 2-σ ellipse
        w, h, angle = _cov_to_ellipse_params(covs[c])
        ell = Ellipse(
            xy=means[c],
            width=w, height=h, angle=angle,
            edgecolor=COLORS[idx % len(COLORS)],
            facecolor="none", linewidth=2.5,
        )
        ax.add_patch(ell)
        ax.scatter(*means[c], marker="*", s=200,
                   color=COLORS[idx % len(COLORS)], zorder=5)

    ax.set_title(title)
    ax.legend(loc="upper right", fontsize=8)
    ax.set_xlabel("Feature 1")
    ax.set_ylabel("Feature 2")
    ax.autoscale()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return ax


def plot_log_likelihood(
    history: list,
    title: str = "GMM Log-Likelihood Convergence",
    ax: plt.Axes | None = None,
    save_path: str | None = None,
):
    """Plot GMM log-likelihood vs. EM iteration."""
    if ax is None:
        _, ax = plt.subplots(figsize=(6, 4))
    ax.plot(range(1, len(history) + 1), history, marker="o", markersize=4, color="#2ECC71")
    ax.set_xlabel("EM Iteration")
    ax.set_ylabel("Log-Likelihood")
    ax.set_title(title)
    ax.grid(True, linestyle="--", alpha=0.5)
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return ax


# ---------------------------------------------------------------------------
# GMM background subtraction
# ---------------------------------------------------------------------------

def plot_foreground_background(
    original: np.ndarray,
    foreground: np.ndarray,
    background: np.ndarray,
    save_path: str | None = None,
):
    """Show original | foreground | background side by side."""
    fig, axes = plt.subplots(1, 3, figsize=(15, 5))
    for ax, img, ttl in zip(
        axes,
        [original, foreground, background],
        ["Original", "Foreground", "Background"],
    ):
        ax.imshow(np.clip(img, 0, 255).astype(np.uint8))
        ax.set_title(ttl)
        ax.axis("off")
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    return fig
