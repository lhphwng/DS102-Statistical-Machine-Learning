# K-Means & GMM — Python Project

Pure-NumPy implementations of **K-Means Clustering** and **Gaussian Mixture Model (GMM)** trained with the **EM algorithm**, covering all five assignments.

---

## Project Structure

```
kmeans_gmm_project/
│
├── data/
│   ├── __init__.py
│   └── data_generator.py       # All dataset generators (NumPy only)
│
├── models/
│   ├── __init__.py
│   ├── kmeans.py               # K-Means EM implementation (NumPy only)
│   └── gmm.py                  # GMM EM implementation (NumPy only)
│
├── visualization/
│   ├── __init__.py
│   ├── plotter.py              # Matplotlib plotting helpers
│   └── metrics.py              # Clustering evaluation metrics (NumPy only)
│
├── main_kmeans_a1.py           # K-Means Assignment 1 (balanced dataset)
├── main_kmeans_a2.py           # K-Means Assignment 2 (imbalanced dataset)
├── main_kmeans_a3.py           # K-Means Assignment 3 (anisotropic covariance)
├── main_gmm_a1.py              # GMM Assignment 1 (implement & train GMM)
├── main_gmm_a2.py              # GMM Assignment 2 (background subtraction)
│
├── results/                    # Auto-created; output figures saved here
│   ├── kmeans_a1/
│   ├── kmeans_a2/
│   ├── kmeans_a3/
│   ├── gmm_a1/
│   └── gmm_a2/
│
└── README.md
```

---

## Dependencies

```
numpy
matplotlib
```

Install with:
```bash
pip install numpy matplotlib
```

No scikit-learn or other ML libraries are used for the core algorithms.

---

## How to Run

Run each assignment from the **project root** directory:

```bash
# K-Means Assignment 1: Balanced dataset + random init sensitivity
python main_kmeans_a1.py

# K-Means Assignment 2: Imbalanced dataset (1200 / 200 / 1000)
python main_kmeans_a2.py

# K-Means Assignment 3: Anisotropic covariance Σ2 = diag(10,1)
python main_kmeans_a3.py

# GMM Assignment 1: Implement & train GMM with EM
python main_gmm_a1.py

# GMM Assignment 2: Background subtraction (uses synthetic image by default)
python main_gmm_a2.py

# GMM Assignment 2: With your own image
python main_gmm_a2.py --image path/to/your/photo.png --k 3 --threshold 0.5
```

All figures are saved to the `results/` directory.

---

## Algorithm Summary

### K-Means (EM view)
| Step   | Operation                                            |
|--------|------------------------------------------------------|
| Init   | Random centroid selection or KMeans++                |
| E-step | Hard assignment: label_i = argmin_k dist(x_i, μ_k)  |
| M-step | Update centroids: μ_k = mean of assigned points      |
| Stop   | Centroid shift < tol  OR  max_iter reached           |

### Gaussian Mixture Model (EM)
| Step   | Operation                                                       |
|--------|-----------------------------------------------------------------|
| Init   | Weights = 1/k, Means from KMeans, Covs = empirical cov of X    |
| E-step | Soft assign: r_{nk} = π_k N(x_n; μ_k, Σ_k) / Σ_j π_j N(...)  |
| M-step | π_k = Σ r_{nk}/n,  μ_k = Σ r_{nk} x_n / Σ r_{nk},  Σ_k = weighted cov |
| Stop   | |ΔlogL| < tol  OR  max_iter reached                           |

---

## Output Files

| Assignment      | Files Generated                                              |
|-----------------|--------------------------------------------------------------|
| K-Means A1      | `a1_clusters.png`, `a1_inertia_curve.png`, `a1_random_init_sensitivity.png` |
| K-Means A2      | `a2_clusters.png`, `a2_inertia_curve.png`, `a2_comparison_inertia.png`      |
| K-Means A3      | `a3_clusters.png`, `a3_inertia_curve.png`                   |
| GMM A1          | `gmm_a1_components.png`, `gmm_a1_loglik.png`, `gmm_a1_clusters.png`, `gmm_a1_vs_kmeans.png` |
| GMM A2          | `gmm_a2_bg_subtraction.png`, `gmm_a2_prob_map.png`, `gmm_a2_pixel_labels.png`, `gmm_a2_loglik.png` |
