"""
metrics.py
----------
Cluster evaluation metrics implemented with NumPy only.
"""

import numpy as np


def cluster_purity(y_true: np.ndarray, y_pred: np.ndarray) -> float:
    """
    Cluster purity: for each predicted cluster take the majority true label,
    then compute the fraction of correctly assigned points.

    Parameters
    ----------
    y_true : (n,)  ground-truth class labels
    y_pred : (n,)  predicted cluster labels

    Returns
    -------
    purity : float in [0, 1]
    """
    n = len(y_true)
    unique_pred = np.unique(y_pred)
    correct = 0
    for c in unique_pred:
        mask = y_pred == c
        # Most frequent true label in this cluster
        true_labels_in_cluster = y_true[mask]
        counts = np.bincount(true_labels_in_cluster.astype(int))
        correct += counts.max()
    return correct / n


def contingency_matrix(y_true: np.ndarray, y_pred: np.ndarray) -> np.ndarray:
    """Return a contingency table (n_true_classes × n_pred_clusters)."""
    n_true = len(np.unique(y_true))
    n_pred = len(np.unique(y_pred))
    mat = np.zeros((n_true, n_pred), dtype=int)
    for t, p in zip(y_true.astype(int), y_pred.astype(int)):
        mat[t, p] += 1
    return mat


def wcss(X: np.ndarray, labels: np.ndarray, centroids: np.ndarray) -> float:
    """Within-cluster sum of squares."""
    total = 0.0
    for j in range(len(centroids)):
        mask = labels == j
        if mask.sum() > 0:
            total += np.sum((X[mask] - centroids[j]) ** 2)
    return total
