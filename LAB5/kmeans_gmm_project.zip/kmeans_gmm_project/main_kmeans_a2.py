"""
main_kmeans_a2.py
=================
K-Means Assignment 2
--------------------
Dataset : 2400 IMBALANCED points
          N((2,2), I)  × 1200 pts
          N((8,3), I)  ×  200 pts
          N((3,6), I)  × 1000 pts

Tasks
-----
1. Generate dataset.
2. Implement K-Means (EM) using NumPy only.
3. Train and evaluate.
4. Comment on the effect of different cluster sizes on K-Means performance.

Run
---
    python main_kmeans_a2.py
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))

from data import generate_dataset_kmeans_a2
from models import KMeans
from visualization import (
    plot_true_vs_predicted,
    plot_inertia_curve,
    cluster_purity,
    contingency_matrix,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "results", "kmeans_a2")
os.makedirs(OUT_DIR, exist_ok=True)


def main():
    print("=" * 65)
    print("  K-Means Assignment 2 — Imbalanced Dataset")
    print("=" * 65)

    # ------------------------------------------------------------------
    # 1. Generate dataset
    # ------------------------------------------------------------------
    X, y_true = generate_dataset_kmeans_a2(seed=42)
    print(f"\n[Data] Shape: {X.shape}")
    unique, counts = np.unique(y_true, return_counts=True)
    print(f"       Class distribution: {dict(zip(unique, counts))}")
    print(f"       Sizes ratio: {counts[0]}:{counts[1]}:{counts[2]}")

    # ------------------------------------------------------------------
    # 2 & 3. Train K-Means
    # ------------------------------------------------------------------
    km = KMeans(k=3, max_iter=300, tol=1e-4, init="random", n_init=10, random_state=0)
    km.fit(X)

    purity = cluster_purity(y_true, km.labels_)
    print(f"\n[K-Means] Converged in {km.n_iter_} iterations")
    print(f"          Final inertia : {km.inertia_:.2f}")
    print(f"          Cluster purity: {purity:.4f}")

    # Predicted cluster sizes
    pred_unique, pred_counts = np.unique(km.labels_, return_counts=True)
    print(f"\n          Predicted cluster sizes: {dict(zip(pred_unique, pred_counts))}")
    print(f"          Discovered centroids:\n{km.centroids_}")

    # Contingency matrix
    cont = contingency_matrix(y_true, km.labels_)
    print(f"\n          Contingency matrix (true × predicted):\n{cont}")

    # ------------------------------------------------------------------
    # Plot 1 – Ground truth vs predicted
    # ------------------------------------------------------------------
    fig = plot_true_vs_predicted(
        X, y_true, km.labels_,
        suptitle="K-Means A2 — Imbalanced Dataset (1200 / 200 / 1000)",
        save_path=os.path.join(OUT_DIR, "a2_clusters.png"),
    )
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 2 – Inertia convergence
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(6, 4))
    plot_inertia_curve(
        km.inertia_history_,
        title="K-Means A2 — Inertia Convergence",
        ax=ax,
    )
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "a2_inertia_curve.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Extra: compare balanced (A1) vs imbalanced (A2) inertia
    # ------------------------------------------------------------------
    from data import generate_dataset_kmeans_a1
    X1, y1 = generate_dataset_kmeans_a1(seed=42)
    km1 = KMeans(k=3, max_iter=300, tol=1e-4, init="random", n_init=10, random_state=0)
    km1.fit(X1)

    fig, axes = plt.subplots(1, 2, figsize=(12, 4))
    plot_inertia_curve(km1.inertia_history_, title="A1 Balanced (600 pts)", ax=axes[0])
    plot_inertia_curve(km.inertia_history_,  title="A2 Imbalanced (2400 pts)", ax=axes[1])
    fig.suptitle("Convergence Comparison: Balanced vs Imbalanced", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "a2_comparison_inertia.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Commentary
    # ------------------------------------------------------------------
    print("""
┌─────────────────────────────────────────────────────────────────┐
│        COMMENT: Effect of Different Cluster Sizes               │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  K-Means MINIMISES inertia (WCSS) — it does not explicitly      │
│  account for cluster sizes:                                     │
│                                                                 │
│  1. CENTROID BIAS: centroids of large clusters are pulled       │
│     strongly towards the dense mass of their many points.      │
│     Small clusters risk having their centroid "stolen" by a     │
│     large neighbouring cluster.                                 │
│                                                                 │
│  2. BOUNDARY SHIFT: the Voronoi boundary between a large and    │
│     a small cluster is pushed away from the large cluster's     │
│     centroid, causing the large cluster to absorb points that   │
│     geometrically belong to the small cluster.                  │
│                                                                 │
│  3. MISCLASSIFICATION: the 200-point cluster N((8,3), I) is     │
│     well-separated here, so it is recovered accurately.         │
│     If it were near a 1200-point cluster, it would likely be    │
│     swallowed entirely.                                         │
│                                                                 │
│  4. SOLUTION: GMM (with full covariance + mixing weights) can   │
│     model cluster sizes explicitly via the π_k weights, making  │
│     it more robust to class imbalance.                          │
└─────────────────────────────────────────────────────────────────┘
""")

    print(f"[Done] Figures saved to: {OUT_DIR}/")


if __name__ == "__main__":
    main()
