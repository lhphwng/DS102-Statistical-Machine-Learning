"""
main_kmeans_a3.py
=================
K-Means Assignment 3
--------------------
Dataset : 600 points with DIFFERENT COVARIANCES
          N((2,2), Σ1)  ×  200 pts   Σ1 = I
          N((8,3), Σ1)  ×  200 pts
          N((3,6), Σ2)  ×  200 pts   Σ2 = diag(10, 1)  ← elongated cluster

Tasks
-----
1. Generate dataset.
2. Implement K-Means (EM) using NumPy only.
3. Train and evaluate.
4. Comment on the effect of N((3,6), Σ2) on K-Means performance.

Run
---
    python main_kmeans_a3.py
"""

import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))

from data import generate_dataset_kmeans_a3
from models import KMeans
from visualization import (
    plot_true_vs_predicted,
    plot_inertia_curve,
    cluster_purity,
    contingency_matrix,
)

OUT_DIR = os.path.join(os.path.dirname(__file__), "results", "kmeans_a3")
os.makedirs(OUT_DIR, exist_ok=True)


def main():
    print("=" * 65)
    print("  K-Means Assignment 3 — Anisotropic Covariance (Σ2)")
    print("=" * 65)

    # ------------------------------------------------------------------
    # 1. Generate dataset
    # ------------------------------------------------------------------
    X, y_true = generate_dataset_kmeans_a3(seed=42)
    print(f"\n[Data] Shape: {X.shape}")
    unique, counts = np.unique(y_true, return_counts=True)
    print(f"       Cluster distribution: {dict(zip(unique, counts))}")
    print("       Cluster 2 has anisotropic covariance Σ2 = diag(10,1)")

    # ------------------------------------------------------------------
    # 2 & 3. Train K-Means
    # ------------------------------------------------------------------
    km = KMeans(k=3, max_iter=300, tol=1e-4, init="random", n_init=15, random_state=0)
    km.fit(X)

    purity = cluster_purity(y_true, km.labels_)
    print(f"\n[K-Means] Converged in {km.n_iter_} iterations")
    print(f"          Final inertia : {km.inertia_:.2f}")
    print(f"          Cluster purity: {purity:.4f}")

    pred_unique, pred_counts = np.unique(km.labels_, return_counts=True)
    print(f"\n          Predicted cluster sizes: {dict(zip(pred_unique, pred_counts))}")
    print(f"          Discovered centroids:\n{km.centroids_}")

    cont = contingency_matrix(y_true, km.labels_)
    print(f"\n          Contingency matrix (true × predicted):\n{cont}")

    # ------------------------------------------------------------------
    # Plot 1 – Compare ground truth vs predicted, with annotations
    # ------------------------------------------------------------------
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # Ground truth
    from visualization.plotter import COLORS
    for idx, c in enumerate(np.unique(y_true)):
        mask = y_true == c
        label_str = (
            f"True cluster {c}  (Σ1=I)" if c < 2 else f"True cluster {c}  (Σ2=diag(10,1))"
        )
        axes[0].scatter(X[mask, 0], X[mask, 1],
                        color=COLORS[idx], alpha=0.45, s=20, label=label_str)
    axes[0].set_title("Ground Truth")
    axes[0].legend(fontsize=8)
    axes[0].set_xlabel("Feature 1"); axes[0].set_ylabel("Feature 2")

    # Predicted
    for idx, c in enumerate(np.unique(km.labels_)):
        mask = km.labels_ == c
        axes[1].scatter(X[mask, 0], X[mask, 1],
                        color=COLORS[idx], alpha=0.45, s=20, label=f"Pred cluster {c}")
    axes[1].scatter(km.centroids_[:, 0], km.centroids_[:, 1],
                    marker="*", s=300, c="black", zorder=5, label="Centroids")
    axes[1].set_title("K-Means Prediction")
    axes[1].legend(fontsize=8)
    axes[1].set_xlabel("Feature 1"); axes[1].set_ylabel("Feature 2")

    fig.suptitle("K-Means A3 — Effect of Anisotropic Covariance Σ2", fontweight="bold")
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "a3_clusters.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Plot 2 – Inertia convergence
    # ------------------------------------------------------------------
    fig, ax = plt.subplots(figsize=(6, 4))
    plot_inertia_curve(km.inertia_history_, title="K-Means A3 — Inertia Convergence", ax=ax)
    fig.tight_layout()
    fig.savefig(os.path.join(OUT_DIR, "a3_inertia_curve.png"), dpi=150)
    plt.close(fig)

    # ------------------------------------------------------------------
    # Commentary
    # ------------------------------------------------------------------
    print("""
┌─────────────────────────────────────────────────────────────────┐
│  COMMENT: Effect of N((3,6), Σ2) with Σ2=diag(10,1) on         │
│           K-Means Performance                                   │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│  K-Means assumes clusters are:                                  │
│    ① ISOTROPIC  (spherical, equal spread in every direction)    │
│    ② of roughly EQUAL SIZE                                      │
│                                                                 │
│  The distribution N((3,6), Σ2) with Σ2=diag(10,1) violates     │
│  assumption ①:                                                  │
│                                                                 │
│  • Σ2 = diag(10,1) creates an ELONGATED elliptical cluster      │
│    (spread 10× wider along the x-axis than along y).            │
│                                                                 │
│  • K-Means uses EUCLIDEAN distance to assign points to the      │
│    nearest centroid. Euclidean distance treats both axes         │
│    equally; it cannot adapt to the elongated shape.             │
│                                                                 │
│  • As a result, K-Means may SPLIT the elongated cluster into    │
│    two sub-clusters (one centroid per "wing") or let             │
│    neighbouring clusters absorb its extremities.                │
│                                                                 │
│  • The overlap between the elongated cluster and its            │
│    neighbours (N((2,2), I) at similar y-range) worsens          │
│    misclassification near the boundary.                         │
│                                                                 │
│  • SOLUTION: GMM with FULL covariance matrices models each      │
│    cluster's shape independently. The Mahalanobis distance      │
│    inside the GMM E-step stretches/rotates the distance metric  │
│    to match the cluster's actual covariance, recovering the     │
│    elongated cluster correctly.                                 │
└─────────────────────────────────────────────────────────────────┘
""")

    print(f"[Done] Figures saved to: {OUT_DIR}/")


if __name__ == "__main__":
    main()
